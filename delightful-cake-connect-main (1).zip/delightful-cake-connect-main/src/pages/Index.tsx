
import React, { useEffect } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import CakeGallery from '@/components/CakeGallery';
import Footer from '@/components/Footer';
import { Cart } from '@/components/Cart';
import { Toaster } from "@/components/ui/toaster";
import { ShoppingCartProvider } from '@/contexts/ShoppingCartContext';

const Index = () => {
  useEffect(() => {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth'
          });
        }
      });
    });
  }, []);

  return (
    <ShoppingCartProvider>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Hero />
          <CakeGallery />
        </main>
        <Cart />
        <Footer />
        <Toaster />
      </div>
    </ShoppingCartProvider>
  );
};

export default Index;
