
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useShoppingCart } from '@/contexts/ShoppingCartContext';
import { ShoppingCart, X } from 'lucide-react';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { useToast } from '@/hooks/use-toast';

export function Cart() {
  const { items, removeItem, clearCart } = useShoppingCart();
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [delivery, setDelivery] = useState("pickup");
  const [specialRequest, setSpecialRequest] = useState("");

  const handleCheckout = () => {
    if (!name) {
      toast({
        variant: "destructive",
        title: "Please enter your name",
        description: "We need your name to process your order."
      });
      return;
    }

    if (items.length === 0) {
      toast({
        variant: "destructive",
        title: "Your cart is empty",
        description: "Please add some items to your cart first."
      });
      return;
    }

    const itemsList = items.map(item => `${item.name} (${item.size})`).join(", ");
    const message = `Hi, I'd like to order the following cakes: ${itemsList}. I chose ${delivery} delivery. My name is ${name}. ${specialRequest ? `Here's a note: ${specialRequest}` : ''}`;
    
    const phoneNumber = "27635214599"; // Updated to South African country code format (+27)
    const encodedMessage = encodeURIComponent(message);
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    
    window.open(whatsappURL, '_blank');
    clearCart();
  };

  return (
    <div 
      id="cart-panel"
      className="fixed top-0 right-0 w-full md:w-96 bg-white border-l border-cake-pink/20 shadow-lg h-full transform translate-x-full transition-transform duration-300 ease-in-out z-40"
    >
      <div className="h-full overflow-y-auto p-4 pt-20">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-serif text-xl font-semibold text-cake-brown flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Your Cart ({items.length})
          </h3>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => document.getElementById('cart-panel')?.classList.add('translate-x-full')}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {items.length > 0 ? (
          <div className="space-y-4">
            {items.map((item) => (
              <div key={item.id} className="flex justify-between items-center p-2 bg-cake-cream/20 rounded-lg">
                <div>
                  <p className="font-medium">{item.name}</p>
                  <p className="text-sm text-gray-600">Size: {item.size}</p>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => removeItem(item.id)}
                  className="text-gray-500 hover:text-red-500"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}

            <div className="space-y-4 mt-4">
              <div>
                <Label htmlFor="name">Your Name</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                  className="mt-1"
                />
              </div>

              <div>
                <Label>Delivery Option</Label>
                <RadioGroup value={delivery} onValueChange={setDelivery} className="mt-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="pickup" id="pickup" />
                    <Label htmlFor="pickup">Pickup</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="delivery" id="delivery" />
                    <Label htmlFor="delivery">Delivery</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label htmlFor="special-request">Special Request (Optional)</Label>
                <Input
                  id="special-request"
                  value={specialRequest}
                  onChange={(e) => setSpecialRequest(e.target.value)}
                  placeholder="Any special instructions..."
                  className="mt-1"
                />
              </div>

              <Button 
                className="w-full bg-cake-pink hover:bg-pink-400 text-pink-900"
                onClick={handleCheckout}
              >
                Complete Order on WhatsApp
              </Button>
            </div>
          </div>
        ) : (
          <p className="text-center text-gray-500 py-4">Your cart is empty</p>
        )}
      </div>
    </div>
  );
}
