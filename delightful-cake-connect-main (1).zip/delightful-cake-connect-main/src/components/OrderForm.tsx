import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { CakeSlice, MessageSquare, Truck, Heart } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const OrderForm = () => {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [flavor, setFlavor] = useState("");
  const [size, setSize] = useState("");
  const [specialRequest, setSpecialRequest] = useState("");
  const [delivery, setDelivery] = useState("pickup");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!name || !flavor || !size) {
      toast({
        variant: "destructive",
        title: "Please complete all required fields",
        description: "We need your name, cake flavor and size to process your order."
      });
      return;
    }
    
    // Format WhatsApp message
    const message = `Hi, I'd like to order a ${flavor} cake, size ${size}. My name is ${name}. I selected ${delivery} delivery. ${specialRequest ? `Here's my message: ${specialRequest}` : ''}`;
    
    // Encode for URL
    const encodedMessage = encodeURIComponent(message);
    
    // WhatsApp phone number - updated to correct number
    const phoneNumber = "0635214599";
    
    // Construct WhatsApp URL
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    
    // Open WhatsApp in new tab
    window.open(whatsappURL, '_blank');
    
    toast({
      title: "Thank you!",
      description: "Opening WhatsApp to complete your order...",
      duration: 5000,
    });
  };

  return (
    <section id="order" className="py-12 md:py-24 bg-gradient-to-b from-cake-pink/20 to-cake-cream/30">
      <div className="container px-4 md:px-6 mx-auto">
        <div className="flex flex-col items-center justify-center text-center mb-10">
          <div className="inline-block p-2 bg-cake-peach rounded-full mb-4">
            <MessageSquare className="h-6 w-6 text-cake-brown" />
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-cake-brown">Order Your Cake</h2>
          <p className="text-gray-600 mt-2 max-w-2xl">
            Fill out the form below and we'll contact you via WhatsApp to confirm your order
          </p>
        </div>

        <Card className="max-w-2xl mx-auto border-cake-pink/30 shadow-lg">
          <CardContent className="p-6 md:p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Your Name</Label>
                <Input 
                  id="name" 
                  placeholder="Enter your name" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="rounded-lg border-cake-pink/30 focus:border-pink-400 focus:ring-pink-400"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cake-flavor">Cake Flavor 🎂</Label>
                <Select value={flavor} onValueChange={setFlavor} required>
                  <SelectTrigger className="rounded-lg border-cake-pink/30 focus:border-pink-400 focus:ring-pink-400">
                    <SelectValue placeholder="Select a flavor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Vanilla">Vanilla</SelectItem>
                    <SelectItem value="Chocolate">Chocolate</SelectItem>
                    <SelectItem value="Red Velvet">Red Velvet</SelectItem>
                    <SelectItem value="Lemon">Lemon</SelectItem>
                    <SelectItem value="Carrot">Carrot</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cake-size">Cake Size</Label>
                <Select value={size} onValueChange={setSize} required>
                  <SelectTrigger className="rounded-lg border-cake-pink/30 focus:border-pink-400 focus:ring-pink-400">
                    <SelectValue placeholder="Select a size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Small">Small</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Large">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="special-request">Special Request (Optional)</Label>
                <Textarea 
                  id="special-request" 
                  placeholder="Any special instructions or requests for your cake..."
                  value={specialRequest}
                  onChange={(e) => setSpecialRequest(e.target.value)}
                  className="rounded-lg border-cake-pink/30 focus:border-pink-400 focus:ring-pink-400 min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label>Delivery Option 🛵</Label>
                <RadioGroup value={delivery} onValueChange={setDelivery} className="flex flex-col space-y-3 mt-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="pickup" id="pickup" />
                    <Label htmlFor="pickup" className="flex items-center cursor-pointer">
                      <span className="ml-2">Pickup</span>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="uber" id="uber" />
                    <Label htmlFor="uber" className="flex items-center cursor-pointer">
                      <span className="ml-2">Uber Delivery</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-cake-pink hover:bg-pink-400 text-pink-900 rounded-full py-6 text-lg font-medium shadow-md transition-all hover:shadow-lg"
              >
                <CakeSlice className="mr-2 h-5 w-5" /> Order Now
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default OrderForm;
