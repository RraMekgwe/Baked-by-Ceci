
import React from 'react';
import { Heart, Instagram, Facebook } from 'lucide-react';

const TikTokIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 48 48"
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M32.5752 8.00084C34.7174 10.0396 35.9434 12.8413 35.9434 16.0845H40.7669C40.7669 11.7348 38.6437 7.82654 35.3511 5.27762C35.1992 5.15701 35.0449 5.04106 34.8884 4.93066C34.165 4.41371 33.3909 3.98998 32.5752 3.67358V8.00084ZM32.5439 16.0845V25.1312C32.5439 28.5162 29.8002 31.2598 26.4152 31.2598C23.0302 31.2598 20.2866 28.5162 20.2866 25.1312C20.2866 21.7462 23.0302 19.0025 26.4152 19.0025C26.9488 19.0025 27.4655 19.0777 27.9538 19.2176V14.8506C27.4553 14.7906 26.9403 14.7653 26.4152 14.7653C20.6573 14.7653 16.0001 19.4224 16.0001 25.1312C16.0001 30.8891 20.6573 35.5463 26.4152 35.5463C32.173 35.5463 36.8302 30.8891 36.8302 25.1312V8.07239C38.9268 9.59753 41.51 10.4353 44.2493 10.4353V6.19876C37.8605 6.19876 32.5439 0.880229 32.5439 0.880229V16.0845Z"
    />
  </svg>
);

const Footer = () => {
  return (
    <footer className="w-full py-8 bg-cake-cream/50">
      <div className="container px-4 mx-auto">
        <div className="flex flex-col items-center justify-center text-center">
          <div className="flex items-center text-cake-brown mb-4">
            <Heart className="h-5 w-5 text-pink-500 mr-2 animate-pulse" />
            <p className="font-serif text-lg">We bake with love. Every time.</p>
          </div>
          
          <div className="flex space-x-4 mb-4">
            <a href="https://www.facebook.com/share/16LPRntZjP/" target="_blank" rel="noopener noreferrer" className="text-cake-brown hover:text-pink-500 transition-colors">
              <Facebook className="h-5 w-5" />
              <span className="sr-only">Facebook</span>
            </a>
            <a href="https://www.instagram.com/baked_byceci?utm_source=qr&igsh=MWhuZ3RuMmxyc3A5Nw==" target="_blank" rel="noopener noreferrer" className="text-cake-brown hover:text-pink-500 transition-colors">
              <Instagram className="h-5 w-5" />
              <span className="sr-only">Instagram</span>
            </a>
            <a href="https://www.tiktok.com/@baked.by.ceci?_t=ZM-8vo2z4MhaJJ&_r=1" target="_blank" rel="noopener noreferrer" className="text-cake-brown hover:text-pink-500 transition-colors">
              <TikTokIcon />
              <span className="sr-only">TikTok</span>
            </a>
          </div>
          
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} Pamela PTY LTD. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
