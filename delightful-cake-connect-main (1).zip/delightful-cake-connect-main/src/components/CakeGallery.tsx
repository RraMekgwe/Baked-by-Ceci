
import React, { useState } from 'react';
import { CakeSlice, ShoppingCart, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useShoppingCart } from '@/contexts/ShoppingCartContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

// Rearranged cake array to put Wedding Cake at position 10 (index 9)
const cakes = [
  {
    id: 1,
    name: "Red Velvet",
    description: "Classic and elegant",
    image: "/lovable-uploads/2c0700e3-d5f5-4d2c-ac6a-7f2b916dfa8a.png"
  },
  {
    id: 2,
    name: "Chocolate Bliss",
    description: "Rich and indulgent",
    image: "/lovable-uploads/1d6418e8-e44d-40a6-94ac-711b90e582c8.png"
  },
  {
    id: 3,
    name: "Carrot Cake",
    description: "Spiced and moist",
    image: "https://images.unsplash.com/photo-1571115177098-24ec42ed204d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 4,
    name: "Birthday Special",
    description: "Celebration favorite",
    image: "/lovable-uploads/cab9e88c-22c3-409a-ac94-8c10008ef66f.png"
  },
  {
    id: 5,
    name: "Vanilla",
    description: "Classic and creamy",
    image: "/lovable-uploads/39e628f3-47f5-4c76-b90d-3005d046c28e.png"
  },
  {
    id: 6,
    name: "Coffee Caramel",
    description: "Rich and smooth",
    image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 7,
    name: "Cookies and Cream",
    description: "Crunchy and sweet",
    image: "/lovable-uploads/e76ad1ba-d39b-41c9-824a-4782fd8546c0.png"
  },
  {
    id: 8,
    name: "Black Velvet",
    description: "Dark and decadent",
    image: "https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 9,
    name: "Lemon",
    description: "Zesty and refreshing",
    image: "https://images.unsplash.com/photo-1567171466295-4afa63d45416?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 10,
    name: "Strawberry",
    description: "Sweet and fruity",
    image: "/lovable-uploads/d793ddee-f0b3-49be-9267-9d5dad75460c.png"
  },
  {
    id: 11,
    name: "Wedding Cake",
    description: "Elegant and memorable",
    image: "/lovable-uploads/1e154a6b-f661-4053-b7a4-17653ba1e147.png"
  }
];

const CakeGallery = () => {
  const { addItem } = useShoppingCart();
  const [selectedSizes, setSelectedSizes] = useState<{ [key: number]: string }>({});
  const [customCakeSize, setCustomCakeSize] = useState<string>('Medium');

  const handleAddToCart = (cake: typeof cakes[0]) => {
    const size = selectedSizes[cake.id] || 'Medium';
    addItem({
      id: Date.now(),
      name: cake.name,
      size: size as 'Small' | 'Medium' | 'Large'
    });
    
    toast('Yum!', {
      description: `${cake.name} added to your cart`,
      position: 'top-right',
      duration: 2000,
      classNames: {
        toast: 'bg-pink-100 text-pink-900 border-pink-200',
        description: 'text-pink-700'
      }
    });
  };

  const handleAddCustomCake = () => {
    addItem({
      id: Date.now(),
      name: "Custom Cake",
      size: customCakeSize as 'Small' | 'Medium' | 'Large'
    });
    
    toast('Amazing Choice!', {
      description: `Custom Cake added to your cart`,
      position: 'top-right',
      duration: 2000,
      classNames: {
        toast: 'bg-pink-100 text-pink-900 border-pink-200',
        description: 'text-pink-700'
      }
    });
  };

  return (
    <section id="cakes" className="py-12 md:py-24 bg-cake-light">
      <div className="container px-4 md:px-6 mx-auto">
        <div className="flex flex-col items-center justify-center text-center mb-10 md:mb-16">
          <div className="inline-block p-2 bg-cake-pink rounded-full mb-4">
            <CakeSlice className="h-6 w-6 text-pink-700" />
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-cake-brown">Our Delicious Cakes</h2>
          <p className="text-gray-600 mt-2 max-w-2xl">
            Each cake is handcrafted with premium ingredients and lots of love
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {cakes.map((cake) => (
            <Card key={cake.id} className="cake-card overflow-hidden rounded-xl border-cake-pink/20 shadow-md hover:shadow-lg transition-all duration-300">
              <CardContent className="p-0">
                <div className="relative h-48 md:h-60 overflow-hidden">
                  {cake.id === 1 ? (
                    <div className="w-full h-full">
                      <img
                        src={cake.image}
                        alt={cake.name}
                        className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                      />
                    </div>
                  ) : (
                    <img
                      src={cake.image}
                      alt={cake.name}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                  )}
                </div>
                <div className="p-4 md:p-6 bg-white space-y-4">
                  <h3 className="font-serif text-xl font-semibold text-cake-brown">{cake.name}</h3>
                  <p className="text-gray-600">{cake.description}</p>
                  
                  <div className="space-y-4">
                    <Select
                      value={selectedSizes[cake.id] || 'Medium'}
                      onValueChange={(value) => setSelectedSizes(prev => ({ ...prev, [cake.id]: value }))}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Small">Small</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Large">Large</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button 
                      className="w-full bg-cake-pink hover:bg-pink-400 text-pink-900"
                      onClick={() => handleAddToCart(cake)}
                    >
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Custom Cake Section - now placed after all the cakes */}
        <div className="mt-16">
          <div className="flex flex-col items-center justify-center text-center mb-8">
            <h3 className="text-2xl md:text-3xl font-serif font-bold text-cake-brown">Create Your Dream Cake</h3>
            <p className="text-gray-600 mt-2 max-w-2xl">
              Design a custom cake that's uniquely yours - perfect for any special occasion
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <Card className="overflow-hidden rounded-xl border-cake-pink/20 shadow-md hover:shadow-lg transition-all duration-300">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="h-64 md:h-auto overflow-hidden">
                  <img
                    src="/lovable-uploads/7d85fdab-5d15-4e7e-951c-76d5a70a8c00.png"
                    alt="Custom Cake"
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="p-6 bg-white flex flex-col justify-center space-y-4">
                  <h3 className="font-serif text-2xl font-semibold text-cake-brown">Custom Cake</h3>
                  <p className="text-gray-600">Tell us your dream cake and we'll make it a reality. Perfect for birthdays, weddings, or any celebration!</p>
                  
                  <div className="space-y-4">
                    <Select
                      value={customCakeSize}
                      onValueChange={setCustomCakeSize}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Small">Small</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Large">Large</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button 
                      className="w-full bg-cake-pink hover:bg-pink-400 text-pink-900"
                      onClick={handleAddCustomCake}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add Custom Cake to Cart
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CakeGallery;
