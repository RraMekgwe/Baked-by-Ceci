
import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { useShoppingCart } from '@/contexts/ShoppingCartContext';
import { Button } from './ui/button';

const Header = () => {
  const { items } = useShoppingCart();

  return (
    <header className="w-full py-4 px-4 bg-gradient-to-b from-cake-cream/50 to-transparent fixed top-0 z-50">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="text-center md:text-left mb-4 md:mb-0 flex items-center gap-2">
          <img 
            src="/lovable-uploads/e4fb54c2-0450-4c25-8063-52db925c1d60.png" 
            alt="Baked by Ceci Logo" 
            className="h-12 w-auto"
          />
          <h1 className="font-serif text-3xl md:text-4xl font-bold text-cake-brown">
            Baked <span className="text-pink-500">by Ceci</span>
          </h1>
        </div>
        <div className="flex items-center gap-6">
          <nav>
            <ul className="flex space-x-6">
              <li>
                <a href="#cakes" className="text-cake-brown hover:text-pink-500 transition-colors">
                  Our Cakes
                </a>
              </li>
            </ul>
          </nav>
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative"
            onClick={() => document.getElementById('cart-panel')?.classList.toggle('translate-x-full')}
          >
            <ShoppingCart className="h-6 w-6 text-cake-brown" />
            {items.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-pink-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                {items.length}
              </span>
            )}
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
