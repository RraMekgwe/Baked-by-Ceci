
import React from 'react';
import { Cake } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AspectRatio } from '@/components/ui/aspect-ratio';

const Hero = () => {
  return (
    <section className="w-full py-12 md:py-24 bg-gradient-to-b from-cake-cream/30 to-cake-pink/20">
      <div className="container px-4 md:px-6 mx-auto flex flex-col md:flex-row items-center gap-6 md:gap-12">
        <div className="flex flex-col justify-center space-y-4 md:w-1/2 text-center md:text-left">
          <div className="space-y-2">
            <h1 className="text-4xl font-serif font-bold tracking-tight sm:text-5xl md:text-6xl">
              Delicious Moments Begin Here!
            </h1>
            <p className="mx-auto max-w-[600px] text-gray-700 md:text-xl">
              Handcrafted cakes made with love and premium ingredients for your special celebrations.
            </p>
          </div>
          <div className="flex flex-col md:flex-row gap-4 mx-auto md:mx-0">
            <Button 
              className="bg-cake-pink hover:bg-pink-400 text-pink-900 rounded-full px-8 py-6 text-lg font-medium shadow-md transition-all hover:shadow-lg"
              onClick={() => window.location.href = "#order"}
            >
              <Cake className="mr-2 h-5 w-5" /> Order Your Cake
            </Button>
            <Button
              variant="outline"
              className="border-cake-pink text-cake-brown hover:bg-cake-pink/20 rounded-full px-8 py-6 text-lg font-medium"
              onClick={() => window.location.href = "#cakes"}
            >
              View Our Cakes
            </Button>
          </div>
        </div>
        <div className="md:w-1/2 relative">
          <div className="relative overflow-hidden rounded-2xl shadow-xl">
            <img 
              src="/lovable-uploads/a2330ce6-2c8e-43b3-9622-08262779cdf5.png" 
              alt="Dragon Ball themed birthday cake with person"
              className="w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
          </div>
          <div className="absolute -bottom-6 -right-6 bg-cake-peach p-4 rounded-full shadow-lg animate-float hidden md:block">
            <Cake size={40} className="text-cake-brown" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
